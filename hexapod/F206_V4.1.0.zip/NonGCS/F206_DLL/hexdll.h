/////////////////////////////////////////////////////////////////////////////
// This is a part of the PI-Software Sources
// Copyright (C) 1995-2004 PHYSIK INSTRUMENTE GmbH & Co. KG
// All rights reserved.
//

#ifndef __PI_HEXDLL_DLLMAIN_H_INCLUDED__
#define __PI_HEXDLL_DLLMAIN_H_INCLUDED__

#include <windows.h>
#include "resource.h"		// main symbols

#ifdef __cplusplus
extern "C" {
#endif

#ifdef HEX_DLL
#define FUNC_DECL __declspec(dllexport) WINAPI
#else
#define FUNC_DECL __declspec(dllimport) WINAPI
#endif

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* DLL expoted function interface */
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// DLL initialization function
	BOOL FUNC_DECL HEXDll_Setup( int nPortNo, long nBaudrate );
	BOOL FUNC_DECL connect_rs232(int nPortNr, long BaudRate);
	BOOL FUNC_DECL connect_ni_gpib(int nDevNr, long nDevAddr);
	void FUNC_DECL HEXDll_ReleaseCom();
	BOOL FUNC_DECL HEXDLL_SetupDlg();
// single command functions
	BOOL FUNC_DECL HEXDll_CmdINI();
	BOOL FUNC_DECL HEXDll_CmdINI_A();
	BOOL FUNC_DECL HEXDll_CmdINI_B();

	BOOL FUNC_DECL HEXDll_CmdMOV( double dX, 
								  double dY, 
								  double dZ, 
								  double dU, 
								  double dV, 
								  double dW );
	BOOL FUNC_DECL HEXDll_CmdDMOV( double dX, 
								  double dY, 
								  double dZ, 
								  double dU, 
								  double dV, 
								  double dW );

	BOOL FUNC_DECL HEXDll_CmdSCT(double Time);
	BOOL FUNC_DECL HEXDll_QuySCT(double *Time);

	BOOL FUNC_DECL HEXDll_CmdMWG( double dX, 
								  double dY, 
								  double dZ, 
								  double dU, 
								  double dV, 
								  double dW );
	BOOL FUNC_DECL HEXDll_CmdMOVNano(double dk, double dl, double dm);

	BOOL FUNC_DECL HEXDll_CmdMOV_A(double db);
	BOOL FUNC_DECL HEXDll_CmdMOV_B(double db);


	BOOL FUNC_DECL HEXDll_CmdMovAxis(char c, double newVal);

	BOOL FUNC_DECL HEXDll_CmdVMO( double dX, 
								  double dY, 
								  double dZ, 
								  double dU, 
								  double dV, 
								  double dW,
								  long *reachable);

	BOOL FUNC_DECL HEXDll_CmdSPI( double dR, 
								  double dS, 
								  double dT,
								  long *spi_ok);

	BOOL FUNC_DECL HEXDll_CmdSST(double sst_X, 
								 double sst_Y, 
								 double sst_Z, 
								 double sst_U, 
								 double sst_V, 
								 double sst_W);

	BOOL FUNC_DECL HEXDll_QuySST(double *sst_X, 
								 double *sst_Y, 
								 double *sst_Z, 
								 double *sst_U,
								 double *sst_V, 
								 double *sst_W);



	BOOL FUNC_DECL HEXDll_CmdVEL( double dVelocity );


	BOOL FUNC_DECL HEXDll_CmdVEL_A(double dVel);
	BOOL FUNC_DECL HEXDll_CmdVEL_B(double dVel);
	BOOL FUNC_DECL HEXDll_CmdSVO(long on_off);

	BOOL FUNC_DECL HEXDll_CmdESC();
	BOOL FUNC_DECL HEXDll_CmdSGA( int nGain, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdNAV(int NAV, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );

	BOOL FUNC_DECL HEXDll_CmdSTOP();


// single query functions
	BOOL FUNC_DECL HEXDll_QuyPOS( double *dX, 
								  double *dY, 
								  double *dZ, 
								  double *dU, 
								  double *dV, 
								  double *dW );
	BOOL FUNC_DECL HEXDll_QuyPOSNano(double *dK, double *dL, double *dM);

	BOOL FUNC_DECL HEXDll_QuyPOS_A(double *dA);
	BOOL FUNC_DECL HEXDll_QuyPOS_B(double *dB);

	BOOL FUNC_DECL HEXDll_QuySPI( double *dR, 
								  double *dS, 
								  double *dT );

	BOOL FUNC_DECL HEXDll_QuyVEL( double *dVelocity );
	BOOL FUNC_DECL HEXDll_QuyVEL_A(double *Vel);
	BOOL FUNC_DECL HEXDll_QuyVEL_B(double *Vel);
	BOOL FUNC_DECL HEXDll_QuyMOV_A(BOOL *isReady);
	BOOL FUNC_DECL HEXDll_QuyMOV_B(BOOL *isReady);

	BOOL FUNC_DECL HEXDll_QuySVO(long *on_off);

	BOOL FUNC_DECL HEXDll_QuySGA( int *nGain, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_QuyTAV( double *dAnalog, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_QuyNAV(int *NAV, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );


	BOOL FUNC_DECL HEXDll_QuyTAVParams( char* szUnit, int* pRange, int nOpticalBoard );
	BOOL FUNC_DECL HEXDll_CmdTAVParams( char* szUnit, int Range, int nOpticalBoard );

	BOOL FUNC_DECL HEXDll_QuyMOV( BOOL *bReady );
	BOOL FUNC_DECL HEXDll_QuyERR( int *nErrID );
	BOOL FUNC_DECL HEXDll_QuyRDY( BOOL *bReady );
// Error status-variables function
	void FUNC_DECL HEXDll_GetError(	int *nDLL_Err );

	BOOL FUNC_DECL HEXDll_CmdFSC(long fsc_mode, double fsc_area, double fsc_threshold, 
											double fsc_step, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdFSA(long fsa_mode, double fsa_area, double fsa_threshold, 
											double fsa_step, double align_step, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdFSM(long fsm_mode, double fsm_area, double fsm_threshold, 
											double fsm_step, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2);

	BOOL FUNC_DECL HEXDll_CmdFAS(long fas_mode, double fas_area, double fas_threshold, 
											double fas_step, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdFAM(long fam_mode, double fam_area, double fam_threshold, 
											double fam_step, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdFIO(long fio_mode, double fio_area, double fio_threshold, 
											double fio_step, double fio_angle_area, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdAAP(long aap_mode, double aap_area,
											double aap_step, int aap_nr_repeats, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL HEXDll_CmdFAA(long faa_mode, double faa_area,
											double faa_threshold, BOOL useTmpVel=FALSE, double faa_tempVel=0.1, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );


//EXTENDED FUNCTIONS
	BOOL FUNC_DECL ShowScanDlg();
	BOOL FUNC_DECL AutoAlign (char cAxis1, char cAxis2, double dStepSize1, double dStepSize2,
					double dAreaSize1, double dAreaSize2, int nRepCount, double *pAnalogMax, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );
	BOOL FUNC_DECL AreaScan(char Ax1, char Ax2, double A1Step, double A2Step, 
							int Ax1StNr, int Ax2StNr, double *data, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );

	BOOL FUNC_DECL AxisScan(char Ax1, double A1Step, int Ax1StNr, 
										double *s_data, BOOL bUseOtherBoard=FALSE, int nOpticalBoard=2 );

	void FUNC_DECL HEXDll_ScanSuccess(long *pVal);
	BOOL FUNC_DECL HEXDll_CmdFSN(double xpos, double ypos, double zpos, double upos, double vpos, double wpos,
								 double threshold, int direction, int moveToStart, int symmetricScan, int nOpticalBoard);

	BOOL FUNC_DECL HEXDll_QuyFSN(double* xpos, double* ypos, double* zpos, double* upos, double* vpos, double* wpos, 
								 double* maxVoltage);


	void FUNC_DECL HEXDll_ScanState(long *pVal);

	BOOL FUNC_DECL HEXDll_QuyCST_AB(char* szStageNameA, int buflenA, char* szStageNameB, int buflenB);

	BOOL FUNC_DECL HEXDll_SendString(char* const szSendString);
	BOOL FUNC_DECL HEXDll_ReceiveString(char* szRecString, const int maxlen);
	BOOL FUNC_DECL HEXDll_ClearBuffer();

#ifdef __cplusplus
}
#endif

#endif // __PI_HEXDLL_DLLMAIN_H_INCLUDED__
