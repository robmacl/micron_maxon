/////////////////////////////////////////////////////////////////////////////
// This is a part of the PI-Software Sources
// Copyright (C) 1995-2003 Physik Instrumente (PI) GmbH & Co. KG
// All rights reserved.
//
// This source code belongs to the Dll for the C-880 system
//
// File: F206_GCS_DLL.h
/////////////////////////////////////////////////////////////////////////////


#ifdef __USE_STDAFX_H
#include <stdafx.h>
#else
#include <windows.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#undef FUNC_DECL
#ifdef F206_DLL_EXPORTS
#define FUNC_DECL __declspec(dllexport) WINAPI
#else
#define FUNC_DECL __declspec(dllimport) WINAPI
#endif


/////////////////////////////////////////////////////////////////////////////
// DLL initialization and comm functions
int FUNC_DECL F206_InterfaceSetupDlg(char* const szRegKeyName);
int FUNC_DECL F206_ConnectRS232(const int nPortNr, const long nBaudRate);
int FUNC_DECL F206_ConnectNIgpib(const int nBoard, const long nDevAddr);
int FUNC_DECL F206_FindOnRS(int* pnStartPort, int* pnStartBaud);
BOOL FUNC_DECL F206_IsConnected(const int ID);
void FUNC_DECL F206_CloseConnection(const int ID);
int FUNC_DECL F206_GetError(const int ID);
BOOL FUNC_DECL F206_SetErrorCheck(const int ID, BOOL bErrorCheck);
BOOL FUNC_DECL F206_TranslateError(int errNr, char* szBuffer, const int maxlen);

/////////////////////////////////////////////////////////////////////////////
// special F206 functions

BOOL FUNC_DECL F206_SVO(const int ID, char* const szAxes, BOOL* pbValarray);
BOOL FUNC_DECL F206_qSVO(const int ID, char* const szAxes, BOOL* pbValarray);


BOOL FUNC_DECL F206_qSAI(const int ID, char* szAxes, const int maxlen);
BOOL FUNC_DECL F206_qSAI_ALL(const int ID, char* szAxes, const int maxlen);
BOOL FUNC_DECL F206_qCST(const int ID, char* const szAxes, char* names, const int maxlen);

BOOL FUNC_DECL F206_DMOV(const int ID, char* const szAxes, double* pdValarray);
BOOL FUNC_DECL F206_SCT(const int ID, double time);
BOOL FUNC_DECL F206_qSCT(const int ID, double* pTime);

/////////////////////////////////////////////////////////////////////////////
// general
BOOL FUNC_DECL F206_qVER(const int ID, char* szBuffer, const int maxlen);
BOOL FUNC_DECL F206_qIDN(const int ID, char* szBuffer, const int maxlen);
BOOL FUNC_DECL F206_qERR(const int ID, int* pnError);
BOOL FUNC_DECL F206_qHLP(const int ID, char* szBuffer, const int maxlen);

BOOL FUNC_DECL F206_INI(const int ID, char* const szAxes);

BOOL FUNC_DECL F206_MWG(const int ID, char* const szAxes, double* pdValarray);
BOOL FUNC_DECL F206_MOV(const int ID, char* const szAxes, double* pdValarray);
BOOL FUNC_DECL F206_VMO(const int ID, char* const szAxes, double* pdValarray, BOOL* pbMovePossible);
BOOL FUNC_DECL F206_qPOS(const int ID, char* const szAxes, double* pdValarray);

BOOL FUNC_DECL F206_STP(const int ID);
BOOL FUNC_DECL F206_StopFastScan(const int ID);
BOOL FUNC_DECL F206_SystemAbort(const int ID);

BOOL FUNC_DECL F206_VEL(const int ID, char* const szAxes, double* pdValarray);
BOOL FUNC_DECL F206_qVEL(const int ID, char* const szAxes, double* pdValarray);

BOOL FUNC_DECL F206_HasPosChanged(const int ID, char* const szAxes, BOOL* pbValarray);
BOOL FUNC_DECL F206_IsMoving(const int ID, char* const szAxes, BOOL* pbValarray);

BOOL FUNC_DECL F206_SPI(const int ID, char* const szAxes, double* val);
BOOL FUNC_DECL F206_qSPI(const int ID, char* const szAxes, double* val);

/////////////////////////////////////////////////////////////////////////////
// analog input channels
BOOL FUNC_DECL F206_NAV(const int ID, int nChannel, int nr);
BOOL FUNC_DECL F206_qNAV(const int ID, int nChannel, int* pnNr);
BOOL FUNC_DECL F206_SGA(const int ID, int nChannel, int nGain);
BOOL FUNC_DECL F206_qSGA(const int ID, int nChannel, int* pnGain);
BOOL FUNC_DECL F206_qTAV(const int ID, int nChannel, double* pdValue);

BOOL FUNC_DECL F206_TAVParams(const int ID, const int board, const int range, char* const szUnit);
BOOL FUNC_DECL F206_qTAVParams(const int ID, const int board, int* pRange, char* szUnit, const int maxlen);

/////////////////////////////////////////////////////////////////////////////
// fast scans
BOOL FUNC_DECL F206_IsScanning(const int ID, BOOL* pbIsScanning);
BOOL FUNC_DECL F206_GetScanResult(const int ID, int* pnResult);

BOOL FUNC_DECL F206_FSA(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const double dAlignStepSize, const int nChannel);
BOOL FUNC_DECL F206_FSM(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const int nChannel);
BOOL FUNC_DECL F206_FSC(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const int nChannel);

BOOL FUNC_DECL F206_FIO(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const double dAngularArea, const int nChannel);
BOOL FUNC_DECL F206_FAS(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const int nChannel);
BOOL FUNC_DECL F206_AAP(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dStepSize, const int nrRepPos, const int nChannel);
BOOL FUNC_DECL F206_FAA(const int ID, const char cAxis, const double dArea, const double dThreshold, const int nChannel);
BOOL FUNC_DECL F206_FAM(const int ID, char* const szAxes, const double dArea1, const double dArea2, const double dThreshold, const double dStepSize, const int nChannel);
					
BOOL FUNC_DECL F206_FSN(const int ID, char* const szAxes, const double* valarray, const double dThreshold, const BOOL bInvert, const BOOL bReturn, const BOOL bCenter, const int nBoardNumber);
BOOL FUNC_DECL F206_qFSN(const int ID, char* const szAxes, double* valarray, double* pdMaxValue);

/////////////////////////////////////////////////////////////////////////////
// manual control pad
BOOL FUNC_DECL F206_SST(const int ID, char* const szAxes, double* pdValarray);
BOOL FUNC_DECL F206_qSST(const int ID, char* const szAxes, double* pdValarray);


/////////////////////////////////////////////////////////////////////////////
// macro commands
BOOL FUNC_DECL F206_IsRecordingMacro(const int ID, BOOL* pbRecordingMacro);

BOOL FUNC_DECL F206_MAC_DEL(const int ID, char* const szName);

BOOL FUNC_DECL F206_MAC_START(const int ID, char* const szName);
BOOL FUNC_DECL F206_MAC_START_PARAMS(const int ID, char* const szName, char* const szParams);
BOOL FUNC_DECL F206_qMAC(const int ID, char* const szName, char* szBuffer, const int maxlen);

BOOL FUNC_DECL F206_MAC_BEG(const int ID, char* const szName);
BOOL FUNC_DECL F206_MAC_END(const int ID);
BOOL FUNC_DECL F206_MAC_qERR(const int ID, char* szBuffer, const int maxlen);

BOOL FUNC_DECL F206_SaveMacroToFile(const int ID, char* const szFileName, char* const szMacroName);
BOOL FUNC_DECL F206_LoadMacroFromFile(const int ID, char* const szFileName, char* const szMacroName);
BOOL FUNC_DECL F206_MacroEditor(const int ID);

BOOL FUNC_DECL F206_Commandset(const int ID, char* const szCommand);
BOOL FUNC_DECL F206_GetAnswer(const int ID, char* szAnswer, const int bufsize);
BOOL FUNC_DECL F206_GetAnswerSize(const int ID, int* iAnswerSize);


/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////


#ifdef __cplusplus
}
#endif