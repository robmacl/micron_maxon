/*** buff_rtn.c ***/
#include <dos.h>
#include "ctermdef.h"
						/* local variables */
byte	transmit_buffer[BUFFSIZE],
	receive_buffer[BUFFSIZE],
	*transmit_wr_ptr,*receive_wr_ptr,	/* Address next write char */
	*transmit_rd_ptr,*receive_rd_ptr;	/* Address char to be read */
int	transmit_ptr_diff,receive_ptr_diff;

/*****************************************************************************
*init_buffer:		initialize all bufferpointer
*****************************************************************************/
void init_buffer()
{
  transmit_wr_ptr=transmit_rd_ptr=transmit_buffer;
  receive_wr_ptr =receive_rd_ptr =receive_buffer;
  transmit_ptr_diff=receive_ptr_diff=0;
}

/*****************************************************************************
*put_transmit_char:	write character unconditionend into buffer,
*			returns free buffersize (0 .. BUFFSIZE-1).
*****************************************************************************/
int put_transmit_char(byte *c)
{
  *transmit_wr_ptr++=*c;
  if (transmit_wr_ptr>=transmit_buffer+BUFFSIZE)
    transmit_wr_ptr=transmit_buffer;		/* set pointer to start */
  return (transmit_ptr_diff=transmit_wr_ptr - transmit_rd_ptr) >= 0 ?
    BUFFSIZE -1 - transmit_ptr_diff : transmit_rd_ptr - transmit_wr_ptr -1;
}

/*****************************************************************************
*get_transmit_char:	returns number of nonprocessed character in buffer,
*			set pointer to current character if value > 0.
*****************************************************************************/
int get_transmit_char(byte *c)
{
  if (0==transmit_ptr_diff) return 0;
  *c=*transmit_rd_ptr++;
  if (transmit_rd_ptr>=transmit_buffer + BUFFSIZE)
    transmit_rd_ptr=transmit_buffer;		/* set pointer to start */
  return (transmit_ptr_diff=transmit_wr_ptr - transmit_rd_ptr) > 0 ?
    transmit_ptr_diff : BUFFSIZE + transmit_ptr_diff;
}

/*****************************************************************************
*transmit_buffer_free:	returns free bufferposition, max. BUFFSIZE-1.
*****************************************************************************/
int transmit_buffer_free()
{
  return transmit_ptr_diff >= 0 ?
    BUFFSIZE -1 - transmit_ptr_diff : transmit_rd_ptr - transmit_wr_ptr - 1;
}

/*****************************************************************************
*put_receive_char:	write character unconditionend into buffer,
*			returns free buffersize (0 .. BUFFSIZE-1).
*****************************************************************************/
int put_receive_char(byte *c)
{
  *receive_wr_ptr++=*c;
  if (receive_wr_ptr>=receive_buffer+BUFFSIZE)
    receive_wr_ptr=receive_buffer;		/* set pointer to start */
  return (receive_ptr_diff=receive_wr_ptr - receive_rd_ptr) >= 0 ?
    BUFFSIZE -1 - receive_ptr_diff : receive_rd_ptr - receive_wr_ptr -1;
}

/*****************************************************************************
*get_receive_char:	returns number of nonprocessed character in buffer,
*			set pointer to current character if value > 0.
*****************************************************************************/
int get_receive_char(byte *c)
{
  disable();
  if (0==receive_ptr_diff) {
     enable();
     return 0;
  }
  *c=*receive_rd_ptr++;
  if (receive_rd_ptr>=receive_buffer+BUFFSIZE)
    receive_rd_ptr=receive_buffer;		/* set pointer to start */
  enable();
  return (receive_ptr_diff=receive_wr_ptr - receive_rd_ptr) > 0 ?
    receive_ptr_diff : BUFFSIZE + receive_ptr_diff;
}


/*****************************************************************************
*receive_buffer_free:	returns free bufferposition, max. BUFFSIZE-1.
*****************************************************************************/
int receive_buffer_free()
{
  return receive_ptr_diff >= 0 ?
    BUFFSIZE -1 - receive_ptr_diff : receive_rd_ptr - receive_wr_ptr -1;
}
