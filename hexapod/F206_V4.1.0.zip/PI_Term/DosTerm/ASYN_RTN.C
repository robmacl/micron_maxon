/*** asyn_rtn.c ***/
#include <dos.h>
#include <limits.h>
#include <stdio.h>
#include <conio.h>
#include "ctermdef.h"

#define THR	UART+0			/* 8250/16450 UART-Register */
#define RBR	UART+0
#define IER	UART+1
#define IIR	UART+2
#define LCR	UART+3
#define MCR	UART+4
#define LSR	UART+5
#define MSR	UART+6
#define EOI	0x20			/* non spezified EOI */

void	interrupt (*oldhandler) ();	/* orginal interruptvector */
int	rts;

/*****************************************************************************
*open_port:	init UART, change interruptvectors.
*****************************************************************************/
void open_port()
{
  bioscom(0,SETTINGS,PORT);		/* UART-parameter */
  oldhandler=getvect(IRQ4);	        /* save old interruptvector */
  setvect(IRQ4,uart_int);	        /* new interruptvector */
  outportb(LCR,inportb(LCR) & 0x7f);	/* UART-DLAB=0 */
  (void)inportb(RBR);			/* UART-RBR clear */
  disable();				/* disable interrupts */
  outportb(IER,0x01);			/* enable UART-Rx-Ints */
  outportb(0x21,inportb(0x21) & 0xef);	/* enable IRQ4 in 8259A-IMR */
  outportb(MCR,0x08);			/* set OUT2 */
  enable();
  outportb(MCR,inportb(MCR) | 0x01);	/* DTR on */
  handshake_on();
}

/*****************************************************************************
*close_port:	restore old interruptvectors.
*****************************************************************************/
void close_port()
{
  disable();
  outportb(0x21,inportb(0x21) | 0x10);	/* Disable IRQ4 */
  outportb(IER,0x00);			/* disable RxInt */
  outportb(MCR,0x00);			/* reset OUT2,DTR,RTS */
  setvect(IRQ4,oldhandler);		/* restore Interruptvector */
  enable();
}

/*****************************************************************************
*async_int:	process 8250-UART-receiver-interrupts
*****************************************************************************/
void interrupt uart_int()
{
static byte rbr;

  outportb(0x21,inportb(0x21) | 0x10);	/* disable COM1 Interrupts */
  enable();
  rbr=inportb(RBR);		        /* RxInt */
  if (OFF_LIMIT > put_receive_char(&rbr))
    handshake_off();			/* check buffer and switch
					   handshake off if needed */
  disable();
  outportb(0x21,inportb(0x21) & 0xef);	/* OCW1 */
  outportb(0x20,EOI);			/* OCW2 (EOI) */
}

/*****************************************************************************
*transmit:	returns address of sended character, else NULL.
*****************************************************************************/
byte *transmit()
{
int timeout;
static byte c;

  for (timeout=INT_MAX; !(inportb(MSR) & 0x10) && timeout>0; timeout--) ;
  if (timeout==0) {			/* no reiceiverhandshake */
    printf("\n");
    textcolor(WHITE);
    cprintf("Timeout waiting for CTS !");
    return NULL;
  }
  for (timeout=INT_MAX; !(inportb(LSR) & 0x20) && timeout>0; --timeout) ;
  if (timeout==0) {			/* technical error */
    printf("\n");
    textcolor(WHITE);
    cprintf("Timeout waiting for THR free !");
    return NULL;
  }
  if (get_transmit_char(&c)) {
    outportb(THR,c);			/* transmit character */
  }
  return &c;
}

/*****************************************************************************
*handshake_on:   	switch handshakesignal ON
*****************************************************************************/
void handshake_on()
{
  outportb(MCR,inportb(MCR) | 0x02);		/* RTS on */
  rts=TRUE;
}

/*****************************************************************************
*handshake_off:		switch handshakesignal OFF
*****************************************************************************/
void handshake_off()
{
  outportb(MCR,inportb(MCR) & 0xfd);		/* RTS off */
  rts=FALSE;
}

/*****************************************************************************
*check_handshake:	checks receiver_buffer, switch handshakesignal ON
*			if the write reach the highwater-mark.
*****************************************************************************/
void check_handshake()
{
  if (!rts && ON_LIMIT < receive_buffer_free())
    outportb(MCR,inportb(MCR) | 0x02);
}
