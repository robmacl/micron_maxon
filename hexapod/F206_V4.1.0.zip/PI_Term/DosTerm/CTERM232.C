/*** cterm232.c ***/
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "ctermdef.h"

/*****************************************************************************
* shows a simple terminalemulation
******************************************************************PRI*160293*/
void main()
{
int key;

  clrscr();
  init_buffer();
  open_port();
  printf("\nopen COM%d: 9600Bd, 8Bit, no Parity, 1Stopbit, RTS/CTS-Handshake"
	,PORT+1);
  printf("\nUse F10 to quit Terminal-Emulator\n");

  while (1) {
    if (bioskey(1)) {			/* check keyboard */
      if (F10==(key=getkey())) break;	/* if F10 quit program */
      if (key==CR) {
	putch(CR);
	key=LF;				/* neuer line terminator */
      }
      if (transmit_buffer_free()) 	/* transmit_buffer free ? */
	put_transmit_char(&key);	/* write char into buffer */
      else putch(BEL);			/* no buffer_space */
    }
    process_receiver_char();
    process_transmitter_char();
  }
  close_port();
  printf("\nclose COM%d\n",PORT+1);
}

/*****************************************************************************
*process_receiver_char:		checks receiverbuffer and handshakesignals
*****************************************************************************/
void process_receiver_char()
{
byte c;

  if (get_receive_char(&c)) {		/* receiver_char in buffer ? */
    textcolor(YELLOW);
    putch(c);                   	/* display character */
    if (c==LF) putch(CR);
    check_handshake();
  }
}

/*****************************************************************************
*process_transmitter_char:	checks transmitbuffer and transmit character
*****************************************************************************/
void process_transmitter_char()
{
byte *c_ptr;
					/* transmit_char in buffer ? */
  if (BUFFSIZE-1-transmit_buffer_free())
    if (NULL!=(c_ptr=transmit())) {
      textcolor(LIGHTCYAN);
      putch(*c_ptr);
    }
}

/*****************************************************************************
* getkey:
*****************************************************************************/
int getkey(void)
{
int key, lo, hi;

  key = bioskey(0);
  lo = key & 0X00FF;
  hi = (key & 0XFF00) >> 8;
  return((lo == 0) ? hi + 256 : lo);
}
