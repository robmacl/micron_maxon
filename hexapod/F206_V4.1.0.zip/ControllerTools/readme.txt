Contents of Folder Controller_Tools

DC:
DC: Dos Commander - File management program for DOS (Freeware), 
Functionality is similar to Norton Commander.

Test:
Com_1_2b:
Test program for serial communication between controller and host. 
Start program on Controller and on Host PC, select COM 1, 
type in some letters and press Enter. The letters should appear 
on the other screen, too. Try once versa.

F206leg3.exe: Single leg test program.
Start program and press F5. If you hear any strange or untypical noise 
coming from the mechanics or if any of the 6 graphics (they show the 
output voltage during forward or backward movement of the single legs) 
shows a circle that comes near the red circle, please stop the program 
immediately, pull off the power supply of the mechanics and contact 
your distributor.
If the yellow and green circles have quite small diameters, proceed 
with single leg operation by pressing 1 to 6 for leg selection and 
pressing the cursor up and down keys (please do NOT press the cursor up 
key too often without pressing the cursor down key because the program 
does not check traveling limits of the mechanics). If both directions 
show a straight ramp it means that the leg works correctly. 

f206encd.exe: 
This is a little test program that reads the encoder values of each single axis when the drives of the stage are moved manually (with open housing). It has been designed for service purposes only.




